---
name: Feature request
about: Suggest an idea for this project
title: "[Feature]"
labels: type/feature
assignees: ''
---

## Background & Motivation

## Goals & Acceptance Criteria
- [ ] 
- [ ] 

## Proposed Solution (optional)

## Impact

## Additional context

