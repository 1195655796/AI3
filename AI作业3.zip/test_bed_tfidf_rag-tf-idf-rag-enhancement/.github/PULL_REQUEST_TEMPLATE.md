## Summary
Briefly describe the motivation and context for this PR.

## Changes
- Core changes:
- Impacted areas:
- Breaking changes:

## Checklist
- [ ] Lint/format/test pass locally (ruff/black/pytest)
- [ ] Tests added/updated as needed
- [ ] Docs updated as needed

## Screenshots/Logs (if applicable)

## Related Issues
Fixes #

